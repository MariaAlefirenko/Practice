const express = require("express");
const { ObjectId } = require("mongodb");

module.exports = function (db) {
  const router = express.Router();
  const booksCollection = db.collection("books");

  // Get all books
  router.get("/", async (req, res) => {
    try {
      const books = await booksCollection.find().toArray();
      res.send(books);
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  // Add a new book
  router.post("/", async (req, res) => {
    const { author, title, quantity } = req.body;
    const book = { author, title, quantity };

    try {
      await booksCollection.insertOne(book);
      res.send(book);
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  // Update a book
  router.put("/:id", async (req, res) => {
    const { author, title, quantity } = req.body;

    try {
      const result = await booksCollection.updateOne(
        { _id: new ObjectId(req.params.id) },
        { $set: { author, title, quantity } }
      );

      if (result.matchedCount === 0) {
        return res.status(404).send("Book not found");
      }

      res.send(
        await booksCollection.findOne({ _id: new ObjectId(req.params.id) })
      );
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  // Delete a book
  router.delete("/:id", async (req, res) => {
    try {
      const result = await booksCollection.deleteOne({
        _id: new ObjectId(req.params.id),
      });
      if (result.deletedCount === 0)
        return res.status(404).send("Book not found");
      res.send(result);
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  return router;
};
