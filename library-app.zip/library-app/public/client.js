async function addBook() {
  const author = document.getElementById("author").value;
  const title = document.getElementById("title").value;
  const quantity = document.getElementById("quantity").value;

  const response = await fetch("/api/books", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ author, title, quantity }),
  });

  const book = await response.json();
  loadBooks();
}

async function loadBooks() {
  const response = await fetch("/api/books");
  const books = await response.json();

  const booksTable = document.getElementById("books");
  booksTable.innerHTML = "";

  books.forEach((book) => {
    const row = document.createElement("tr");
    row.innerHTML = `
        <td>${book._id}</td>
        <td>${book.author}</td>
        <td>${book.title}</td>
        <td>${book.quantity}</td>
        <td>
          <button onclick="deleteBook('${book._id}')">Delete</button>
          <button onclick="editBook('${book._id}')">Edit</button>
        </td>
      `;
    booksTable.appendChild(row);
  });
}

async function editBook(id) {
  const author = prompt("Enter new author:");
  const title = prompt("Enter new title:");
  const quantity = prompt("Enter new quantity:");

  const response = await fetch(`/api/books/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ author, title, quantity }),
  });

  const updatedBook = await response.json();
  loadBooks();
}

async function deleteBook(id) {
  await fetch(`/api/books/${id}`, { method: "DELETE" });
  loadBooks();
}

async function deleteAllBooks() {
  const response = await fetch("/api/books");
  const books = await response.json();

  books.forEach(async (book) => {
    await fetch(`/api/books/${book._id}`, { method: "DELETE" });
  });

  loadBooks();
}
