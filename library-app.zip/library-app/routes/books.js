const express = require("express");
const router = express.Router();
const Book = require("../routes/Book");

// Get all books
router.get("/", async (req, res) => {
  try {
    const books = await Book.find();
    res.send(books);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Add a new book
router.post("/", async (req, res) => {
  const { author, title, quantity } = req.body;
  try {
    const newBook = new Book({ author, title, quantity });
    await newBook.save();
    res.send(newBook);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Update a book
router.put("/:id", async (req, res) => {
  const { author, title, quantity } = req.body;
  try {
    const updatedBook = await Book.findByIdAndUpdate(
      req.params.id,
      { author, title, quantity },
      { new: true }
    );
    if (!updatedBook) {
      return res.status(404).send("Book not found");
    }
    res.send(updatedBook);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Delete a book
router.delete("/:id", async (req, res) => {
  try {
    const deletedBook = await Book.findByIdAndDelete(req.params.id);
    if (!deletedBook) {
      return res.status(404).send("Book not found");
    }
    res.send(deletedBook);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

module.exports = router;
